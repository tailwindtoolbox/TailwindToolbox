<?php
header("Location: https://www.tailwindtoolbox.com/starter-templates");
die();
?>